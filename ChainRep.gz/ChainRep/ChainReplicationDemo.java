import chainReplication.*;

import java.io.*;

abstract class ChainReplicationDemo{	
	public static void main(String[] args){
		ChainReplicationDemo demo = null;
		try{
			if(args[0].equalsIgnoreCase("server")){
				demo = new ServerDemo(Integer.parseInt(args[1]), new File(args[2]));
				System.out.println("Creating demo server...");
			}else if(args[0].equalsIgnoreCase("client")){
				demo = new ClientDemo(new File(args[1]));
				System.out.println("Creating demo client...");
			}else if(args[0].equalsIgnoreCase("master")){
				demo = new MasterDemo(new File(args[1]));
				System.out.println("Creating demo master server...");
			}else{
				throw new Exception("Unknown option : " + args[0]);
			}
		}catch(ArrayIndexOutOfBoundsException exc){
			throw new RuntimeException(exc);
			//~ showUsage();
			//~ System.exit(1);
		}catch(Exception exc){
			System.err.println("ERROR : " + exc.getMessage());
			throw new RuntimeException(exc);
			//~ showUsage();
			//~ System.exit(1);
		}
		
		demo.start();
	}
	
	private static void showUsage(){
		System.out.println(
			"Usage: ChainReplicationDemo server id configFile\n" +
			"       ChainReplicationDemo client configFile\n"
		);
	}
	
	
	protected Configuration config;
	protected ChainReplicationDemo(File configFile) throws Exception{
		try{
			this.config = new Configuration(configFile);
		}catch(Exception exc){
			throw new Exception("Bad confuration file.");
		}
	}
	
	abstract void start();
}

class ServerDemo extends ChainReplicationDemo{
	private ChainServer server;
	ServerDemo(int id, File configFile) throws Exception{
		super(configFile);
		ServerConfig pred = config.getServerOptions(id-1);
		ServerConfig succ = config.getServerOptions(id+1);
		server = new ChainServer(
			(pred==null ? null : pred.getAddress()),
			(succ==null ? null : succ.getAddress()),
			config.getServerOptions(id).getPort(),
			config.getServerOptions(id).getUDPPort(),
			config.getMasterAddress()
		);
		if(id == 0){
			//server.activateAsHead(config.getHeadUDPServer().getPort());
		}else if(id == config.getTailID()){
			//server.activateAsTail(config.getTailUDPServer().getPort(), config.getClientListenSocket());
		}
	}
	
	void start(){
		server.start();
	}
}

class ClientDemo extends ChainReplicationDemo{
	private ChainClient client;
	ClientDemo(File configFile) throws Exception{
		super(configFile);
		//client = new ChainClient(config.getHeadUDPServer(), config.getTailUDPServer(), config.getClientListenSocket().getPort(), config.getClientReplyTimeout(), config.getUpdateMessagePercentage());
		client = new ChainClient(
			new java.net.InetSocketAddress(config.getMasterAddress().getAddress(), config.getMasterTCPListenPort()),
			config.getClientListenSocket().getPort(),
			config.getClientReplyTimeout(),
			config.getUpdateMessagePercentage()
		);
		client.seedRandom(config.getSeed());
	}
	
	void start(){
		client.start();
	}
}

class MasterDemo extends ChainReplicationDemo{
	private ChainMaster master;
	MasterDemo(File configFile) throws Exception{
		super(configFile);
		master = new ChainMaster(
			config.getMasterAddress().getPort(),
			config.getMasterTCPListenPort(),
			config.getClientListenSocket()
		);
	}
	
	void start(){
		master.start();
	}
}
