package chainReplication;

import java.net.InetSocketAddress;

public class ServerConfig{
	InetSocketAddress address;
	int udpPort;
	ServerConfig(InetSocketAddress add, int udp){
		this.address = add;
		this.udpPort = udp;
	}

	public InetSocketAddress getAddress(){
		return address;
	}

	public String getHostName(){
		return address.getHostName();
	}

	public int getPort(){
		return address.getPort();
	}

	public int getUDPPort(){
		return udpPort;
	}
}