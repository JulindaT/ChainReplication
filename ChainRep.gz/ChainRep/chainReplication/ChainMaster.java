package chainReplication;

import java.net.*;
import java.io.*;
import java.util.*;

public class ChainMaster {
	private DatagramSocket listenSocket;
	private Vector<ServerInfo> servers;
	private long serverDeathPeriod = 5000;
	private ServerSocket connectionListenSocket;

	private Socket clientSocket;
	private InetSocketAddress clientSocketAddress;

	public ChainMaster(int udpListenPort, int tcpListenPort, InetSocketAddress clientSocketAddress) throws Exception{
		listenSocket = new DatagramSocket(udpListenPort);
		servers = new Vector<ServerInfo>();
		this.clientSocketAddress = clientSocketAddress;

		connectionListenSocket = new ServerSocket(tcpListenPort);
	}

	public void start(){
		startListening();
		while(true){
			checkForDeadServers();
		}
	}

	private void startListening(){
		(new Thread(){
			public void run(){
				while(true){
					getAHeartbeat();
					Thread.yield();
				}
			}
		}).start();
		(new Thread(){
			public void run(){
				try{
					System.out.println("waiting for client...");
					clientSocket = connectionListenSocket.accept();
					System.out.println("got a client at " + clientSocket);
					if(servers.size() > 0){
						byte[] data;
						ServerUpdateMessage m;
						DatagramPacket packet;
						ServerInfo head = servers.get(0);
						ServerInfo tail = servers.get(servers.size()-1);
						try{
							m = new UpdateHeadServer(new InetSocketAddress(head.address.getAddress(), ));
							OutputStream out = clientSocket.getOutputStream();
							out.write(m.serialize());
							out.flush();
						}catch(Exception exc){
							System.err.println("Failed to send updateHeadServer message to client");
							throw new RuntimeException(exc);
						}

						try{
							m = new UpdateTailServer(new InetSocketAddress(tail.address.getAddress(), ));
							OutputStream out = clientSocket.getOutputStream();
							out.write(m.serialize());
							out.flush();
						}catch(Exception exc){
							System.err.println("Failed to send updateTailServer message to client");
							throw new RuntimeException(exc);
						}


					}
				}catch(Exception exc){
					throw new RuntimeException(exc);
				}
			}
		}).start();
	}

	private void checkForDeadServers(){
		long currentTime = System.currentTimeMillis();
		int size = servers.size();
		for(int i=0; i<size; i++){
			ServerInfo si = servers.get(i);
			if(currentTime - si.lastHeartbeatTimestamp > serverDeathPeriod){
				System.out.println("Removing the server at " + si.address);
				// notify servers @ i-1 and i+1
				ServerInfo pred = null;
				if(i > 0) pred = servers.get(i-1);
				ServerInfo succ = null;
				if(i < size-1) succ = servers.get(i+1);

				byte[] data;
				ServerUpdateMessage m;
				DatagramPacket packet;

				if(pred == null && succ != null){
					// new head
					m = new PredecessorUpdateMessage(null);

					data = m.serialize();
					packet = new DatagramPacket(data, data.length, succ.address.getAddress(), succ.address.getPort());
					System.out.println("Sending packet to " + succ.address);
					try{
						listenSocket.send(packet);
					}catch(Exception exc){
						throw new RuntimeException(exc);
					}

					try{
						m = new UpdateHeadServer(succ.address);
						OutputStream out = clientSocket.getOutputStream();
						out.write(m.serialize());
						out.flush();
					}catch(Exception exc){
						System.err.println("Failed to send updateHeadServer message to client");
						throw new RuntimeException(exc);
					}
				}else if(succ == null && pred != null){
					// new tail
					m = new SuccessorUpdateMessage(null);

					data = m.serialize();
					packet = new DatagramPacket(data, data.length, pred.address.getAddress(), pred.address.getPort());
					System.out.println("Sending packet to " + pred.address);
					try{
						listenSocket.send(packet);
					}catch(Exception exc){
						throw new RuntimeException(exc);
					}

					try{
						m = new UpdateTailServer(succ.address);
						OutputStream out = clientSocket.getOutputStream();
						out.write(m.serialize());
						out.flush();
					}catch(Exception exc){
						System.err.println("Failed to send updateTailServer message to client");
						throw new RuntimeException(exc);
					}


				}else{
					// update both
					m = new SuccessorUpdateMessage(succ.address);

					data = m.serialize();
					packet = new DatagramPacket(data, data.length, pred.address.getAddress(), pred.address.getPort());
					System.out.println("Sending packet to " + pred.address);
					try{
						listenSocket.send(packet);
						Thread.sleep(1000);
					}catch(Exception exc){
						throw new RuntimeException(exc);
					}




					
					m = new PredecessorUpdateMessage(new InetSocketAddress(pred.address.getAddress(), pred.tcpListenPort));

					data = m.serialize();
					packet = new DatagramPacket(data, data.length, succ.address.getAddress(), succ.address.getPort());
					System.out.println("Sending packet to " + succ.address);
					try{
						listenSocket.send(packet);
					}catch(Exception exc){
						throw new RuntimeException(exc);
					}

				}
				
				servers.remove(i);
				i--;
				size--;
			}
		}
	
	}

	private void getAHeartbeat(){
		byte[] receiveData = new byte[1024];
		try{
			DatagramPacket receivedPacket = new DatagramPacket(receiveData, receiveData.length);
			listenSocket.receive(receivedPacket);
			InetSocketAddress receivedAddress = (InetSocketAddress)receivedPacket.getSocketAddress();
			Message m = Message.deserialize(receivedPacket.getData());
			if(m instanceof Heartbeat){
				ServerInfo server = null;
				for(ServerInfo si : servers){
					if(si.address.equals(receivedAddress)){
						server = si;
						break;
					}
				}
				if(server == null){
					server = new ServerInfo((InetSocketAddress)receivedPacket.getSocketAddress(), ((Heartbeat)m).tcpListenPort);
					ServerInfo currentTail = servers.size()==0 ? null : servers.get(servers.size()-1);

					servers.add(server);

					byte[] data;
					ServerUpdateMessage sum;
					DatagramPacket packet;
					if(currentTail == null){
						sum = new PredecessorUpdateMessage(null);
	
						data = sum.serialize();
						packet = new DatagramPacket(data, data.length, server.getAddress(), server.getPort());
						System.out.println("Sending Predecessor update to " + server.getAddress());
						try{
							listenSocket.send(packet);
						}catch(Exception exc){
							throw new RuntimeException(exc);
						}


					}else{
						// update both
						sum = new SuccessorUpdateMessage(server.address);
	
						data = sum.serialize();
						packet = new DatagramPacket(data, data.length, currentTail.address.getAddress(), currentTail.address.getPort());
						System.out.println("Sending successor update to " + currentTail.address);
						try{
							listenSocket.send(packet);
							Thread.sleep(1000);
						}catch(Exception exc){
							throw new RuntimeException(exc);
						}

						
						sum = new PredecessorUpdateMessage(new InetSocketAddress(currentTail.address.getAddress(), currentTail.tcpListenPort));
	
						data = sum.serialize();
						packet = new DatagramPacket(data, data.length, server.address.getAddress(), server.address.getPort());
						System.out.println("Sending predecessor update to " + server.address);
						try{
							listenSocket.send(packet);
						}catch(Exception exc){
							throw new RuntimeException(exc);
						}
					}
					sum = new SuccessorUpdateMessage(clientSocketAddress, true);

					data = sum.serialize();
					packet = new DatagramPacket(data, data.length, server.getAddress(), server.getPort());
					System.out.println("Sending packet to " + server.getAddress());
					try{
						listenSocket.send(packet);
					}catch(Exception exc){
						throw new RuntimeException(exc);
					}



				}
				
				server.refresh();
				//System.out.println("Received a heartbeat " + server.address);
			}
		}catch(IOException exc){
			System.err.println(exc);
		}
	}

	
	class ServerInfo{
		long lastHeartbeatTimestamp;
		InetSocketAddress address;
		int tcpListenPort;

		public ServerInfo(InetSocketAddress address, int tcpPort){
			this.address = address;
			this.tcpListenPort = tcpPort;
			refresh();
		}
		
		public void refresh(){
			lastHeartbeatTimestamp = System.currentTimeMillis();
		}

		public InetAddress getAddress(){
			return address.getAddress();
		}

		public int getPort(){
			return address.getPort();
		}

		public boolean equals(ServerInfo other){
			return this.address.equals(other.address);
		}
	}

}
