package chainReplication;


import java.net.*;
import java.io.*;
import java.util.*;

public class ChainServer{
	private Integer dataObject;
	
	private DatagramSocket headSocket;
	private DatagramSocket tailSocket;
	private InetSocketAddress clientSocket;
	private InetSocketAddress masterAddress;
	
	private Socket successorSocket;
	private Socket predecessorSocket;

	private ServerSocket serverSocket;
	
	private Vector<Message> receivedMessages;
	private Vector<ReplyMessage> sentReplies;

	private DatagramSocket masterSocket;
	private int tcpListenPort;
	private int udpListenPort;
	
	public ChainServer(InetSocketAddress predecessor, InetSocketAddress successor, int tcpListenPort, int udpListenPort, InetSocketAddress masterAddress) throws Exception{
		this.masterAddress = masterAddress;
		masterSocket = new DatagramSocket();

		startHeartbeat();
		this.tcpListenPort = tcpListenPort;
		this.udpListenPort = udpListenPort;
		//updatePredecessor(predecessor);
		//updateSuccessor(successor);
		
		receivedMessages = new Vector<Message>();
		sentReplies = new Vector<ReplyMessage>();
		
		dataObject = 0;
	}
	
	public void start(){
		while(true){
			try{
				if(predecessorSocket == null) continue;
				ObjectInputStream ois = new ObjectInputStream(predecessorSocket.getInputStream());
				Message m = (Message)ois.readObject();
				if(m instanceof RawDataUpdateMessage){
					dataObject = ((RawDataUpdateMessage)m).getData();
					if(successorSocket == null){
						ReplyMessage r = new ReplyMessage(m.getID(), dataObject);
						try{
							byte[] data = r.serialize();
							DatagramPacket p = new DatagramPacket(data, data.length, clientSocket.getAddress(), clientSocket.getPort());
							DatagramSocket ds = new DatagramSocket();
							ds.send(p);
							sentReplies.add(r);
						}catch(Exception exc){
							System.err.println("Failed to send reply to client after update : " + r);
						}
					}else{
						RawDataUpdateMessage raw = (RawDataUpdateMessage)m;
						dataObject = raw.getData();
						sendMessageToSuccessor(raw);
					}
				}else if(m instanceof ResendReplyMessage){
					if(successorSocket == null){
						// find the reply and resend it
						System.out.println("Need to resend a message...");
						boolean found = false;
						for(ReplyMessage r : sentReplies){
							if(r.getID() == m.getID()){
								found = true;
								byte[] data = r.serialize();
								DatagramPacket p = new DatagramPacket(data, data.length, clientSocket.getAddress(), clientSocket.getPort());
								DatagramSocket ds = new DatagramSocket();
								ds.send(p);
								System.out.println(r);
								break;
							}
						}
						if(!found){
							ReplyMessage r = new ReplyMessage(m.getID(), dataObject);
							try{
								byte[] data = r.serialize();
								DatagramPacket p = new DatagramPacket(data, data.length, clientSocket.getAddress(), clientSocket.getPort());
								DatagramSocket ds = new DatagramSocket();
								ds.send(p);
								sentReplies.add(r);
							}catch(Exception exc){
								System.err.println("Failed to send reply to client after update : " + r);
							}
						}
					}else{
						sendMessageToSuccessor(m);
					}
				}
			}catch(Exception exc){
				System.err.println("TCP RECEIVE ERROR : " + exc);
				predecessorSocket = null;
			}
		}
	}
	
	private void receiveUpdateMessage(UpdateMessage m){
		// if this message is new, update the data object
		boolean found = false;
		if(receivedMessages.contains(m)){
			System.out.println("Received a duplicate message " + m);
			ResendReplyMessage rrm = new ResendReplyMessage(m.getID());
			sendMessageToSuccessor(rrm);
			
			return;
		}
		receivedMessages.add(m);
		dataObject++;
		
		if(successorSocket != null){
			RawDataUpdateMessage raw = new RawDataUpdateMessage(m.getID(), dataObject);
			sendMessageToSuccessor(raw);
		}else{
			ReplyMessage r = new ReplyMessage(m.getID(), dataObject);
			try{
				System.out.println("replying to client after update");
				byte[] data = r.serialize();
				DatagramPacket p = new DatagramPacket(data, data.length, clientSocket.getAddress(), clientSocket.getPort());
				//tailSocket.send(p);
				DatagramSocket ds = new DatagramSocket();
				ds.send(p);
			}catch(Exception exc){
				System.err.println("Failed to send reply to client : " + r.id);
			}
		}
	}
	
	private void sendMessageToSuccessor(Message m){
		if(successorSocket == null) return;
		try{
			System.out.println("Sending update along the line : " + dataObject);
			OutputStream out = successorSocket.getOutputStream();
			out.write(m.serialize());
			out.flush();
		}catch(Exception exc){
			System.err.println("Failed to send message over TCP : " + m.id);
		}
	}
	
	private void receiveQueryMessage(QueryMessage m, InetSocketAddress sender){
		ReplyMessage r = new ReplyMessage(m.getID(), dataObject);
		try{
			byte[] data = r.serialize();
			DatagramPacket p = new DatagramPacket(data, data.length, clientSocket.getAddress(), clientSocket.getPort());
			DatagramSocket ds = new DatagramSocket();
			ds.send(p);
		}catch(Exception exc){
			System.err.println("Failed to send reply to client : " + r.id);
		}
	}

	
	private void startHeadUDPThread(){
		Thread t = new Thread(){
			public void run(){
System.out.println("[head]Listening for UDP messages on " + udpListenPort);
				while(true){
					// this server is the head
					byte[] receiveData = new byte[1024];
					try{
						DatagramPacket receivedPacket = new DatagramPacket(receiveData, receiveData.length);
						headSocket.receive(receivedPacket);
						Message m = Message.deserialize(receivedPacket.getData());
System.out.println("Received message from client: " + m);
						if(m instanceof UpdateMessage)
							receiveUpdateMessage((UpdateMessage)m);
					}catch(IOException exc){
						System.err.println(exc);
					}
				}
			}
		};
		t.start();
	}
	
	private void startTailUDPThread(){
		Thread t = new Thread(
			new Runnable(){
				public void run(){
System.out.println("[tail]Listening for UDP messages on " + udpListenPort);
					while(true){
						// this server is the head
						byte[] receiveData = new byte[1024];
						try{
							DatagramPacket receivedPacket = new DatagramPacket(receiveData, receiveData.length);
							tailSocket.receive(receivedPacket);
							Message m = Message.deserialize(receivedPacket.getData());
System.out.println("Received message from client: " + m);
							if(m instanceof QueryMessage){
								receiveQueryMessage((QueryMessage)m, new InetSocketAddress(receivedPacket.getAddress(), receivedPacket.getPort()));
							}
						}catch(IOException exc){
							System.err.println(exc);
						}
						
					}
				}
			}
		);
		t.start();
	}
	
	public void activateAsHead() throws Exception{
		headSocket = new DatagramSocket(udpListenPort);
		startHeadUDPThread();
	}
	
	public void activateAsTail(InetSocketAddress clientSocket) throws Exception{
		if(headSocket != null){
			tailSocket = headSocket;
		}else{
			tailSocket = new DatagramSocket(udpListenPort);
			this.clientSocket = clientSocket;
		}
		startTailUDPThread();
	}

	public void updateSuccessor(InetSocketAddress successor, boolean isTail) throws Exception{
		// listen for a connection ONLY from successor
		if(successorSocket != null) successorSocket.close();
		if(serverSocket != null) serverSocket.close();
		if(isTail){
			activateAsTail(successor);
			return;
		}else{
			System.out.println("TCP listening for connections on " + successor.getAddress() + ":" + tcpListenPort);
			serverSocket = new ServerSocket(tcpListenPort);
			successorSocket = serverSocket.accept();
		}
	}
	
	public void updatePredecessor(InetSocketAddress predecessor) throws Exception{
		// connect to predecessor
		if(predecessorSocket != null) predecessorSocket.close();
		if(predecessor == null){
			activateAsHead();
			return;
		}
		System.out.println("TCP connecting on " + predecessor);
		predecessorSocket = new Socket(predecessor.getAddress(), predecessor.getPort());
	}


	private void startHeartbeat(){
		(new Thread(){
			public void run(){
				System.out.println("Heartbeat initialized");
				while(true){
					Heartbeat u = new Heartbeat(tcpListenPort);
					byte[] data = u.serialize();
					DatagramPacket p = new DatagramPacket(data, data.length, masterAddress.getAddress(), masterAddress.getPort());
					try{
						//System.out.println("Sending a heartbeat to " + masterAddress);
						masterSocket.send(p);
					}catch(Exception exc){
						throw new RuntimeException(exc);
					}
					try{Thread.sleep(1000);}catch(Exception exc){}
				}
			}
		}).start();

		Thread t = new Thread(){
			public void run(){
				while(true){
					byte[] receiveData = new byte[1024];
					try{
						DatagramPacket receivedPacket = new DatagramPacket(receiveData, receiveData.length);
						System.out.println("waiting for UDP packet from master");
						masterSocket.receive(receivedPacket);
						Message m = Message.deserialize(receivedPacket.getData());
						if(m instanceof PredecessorUpdateMessage){
							System.out.println("need to update my predecessor");
							updatePredecessor(((PredecessorUpdateMessage)m).getPredecessorAddress());
						}else if(m instanceof SuccessorUpdateMessage){
							SuccessorUpdateMessage sum = (SuccessorUpdateMessage)m;
							System.out.println("need to update my successor");
							updateSuccessor(sum.getSuccessorAddress(), sum.isTail);
						}else{
							System.out.println("received some junk");
							System.out.println("\t" + m);
						}
					}catch(Exception exc){
						System.err.println(exc);
					}
				}
			}
		};
		t.start();
	}
}