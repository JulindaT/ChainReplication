package chainReplication;

import java.io.*;
import java.net.*;

public class Message implements Serializable{
	static long autoIncrementID = 0;
	
	long id;
	public Message(){
		this.id = autoIncrementID++;
	}
	
	public Message(long id){
		this.id = id;
	}
	
	public long getID(){
		return id;
	}
	
	public String toString(){
		return this.getClass() + " : ID = " + this.id;
	}
	
	public byte[] serialize(){
		try{
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			ObjectOutputStream oos = new ObjectOutputStream(baos);
			
			oos.writeObject(this);
			oos.flush();
			oos.close();
			
			return baos.toByteArray();
		}catch(IOException exc){
			System.err.println("Failed to serialize message.");
			System.err.println(exc);
		}
		
		return null;
	}
	
	public static final Message deserialize(byte[] data){
		return deserialize(new ByteArrayInputStream(data));
	}

	public static final Message deserialize(InputStream stream){
		try{
			ObjectInputStream ois = new ObjectInputStream(stream);

			return (Message)ois.readObject();
		}catch(Exception exc){
			System.err.println("Failed to load message from stream");
			throw new RuntimeException(exc);
		}
	}
	
	public boolean equals(Object o){
		if(!(o.getClass().equals(this.getClass()))) return false;
			
		return this.id == ((Message)o).id;
	}

}

class QueryMessage extends Message{
}

class UpdateMessage extends Message{
}

class RawDataUpdateMessage extends Message{
	Integer data;
	public RawDataUpdateMessage(long id, Integer data){
		super(id);
		this.data = data;
	}
	
	public Integer getData(){
		return data;
	}
}

class ReplyMessage extends Message{
	Integer data;
	public ReplyMessage(long id, Integer data){
		super(id);
		this.data = new Integer(data);
	}
	
	public String toString(){
		return super.toString() + " data = " + data;
	}
}

class ResendReplyMessage extends Message{
	public ResendReplyMessage(long id){
		super(id);
	}
}

abstract class ServerUpdateMessage extends Message{
	protected InetSocketAddress newServer;

	protected ServerUpdateMessage(InetSocketAddress newServer){
		this.newServer = newServer;
	}
}

class PredecessorUpdateMessage extends ServerUpdateMessage{
	public PredecessorUpdateMessage(InetSocketAddress newPredecessor){
		super(newPredecessor);
	}

	public InetSocketAddress getPredecessorAddress(){
		return newServer;
	}
}

class SuccessorUpdateMessage extends ServerUpdateMessage{
	boolean isTail;
	public SuccessorUpdateMessage(InetSocketAddress newSuccessor){
		super(newSuccessor);
	}

	public SuccessorUpdateMessage(InetSocketAddress newSuccessor, boolean isTail){
		super(newSuccessor);
		this.isTail = isTail;
	}

	public InetSocketAddress getSuccessorAddress(){
		return newServer;
	}
}

class Heartbeat extends Message{
	int tcpListenPort;
	public Heartbeat(int tcpListenPort){
		this.tcpListenPort = tcpListenPort;
	}
}

class UpdateTailServer extends ServerUpdateMessage{
	UpdateTailServer(InetSocketAddress newTail){
		super(newTail);
	}

	public InetSocketAddress getTailAddress(){
		return newServer;
	}
}

class UpdateHeadServer extends ServerUpdateMessage{
	UpdateHeadServer(InetSocketAddress newHead){
		super(newHead);
	}
	public InetSocketAddress getHeadAddress(){
		return newServer;
	}
}