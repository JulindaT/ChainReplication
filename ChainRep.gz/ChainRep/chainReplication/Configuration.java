package chainReplication;

import java.net.InetSocketAddress;
import java.util.Vector;
import java.util.Scanner;

import java.io.File;

public class Configuration{
	private Vector<ServerConfig> serverOptions = new Vector<ServerConfig>();
	private int headUDPPort;
	private int tailUDPPort;
	private InetSocketAddress clientListenSocket;
	private InetSocketAddress masterAddress;
	private long clientReplyTimeout;
	private double updateMessagePercentage;
	private int masterTCPListenPort;
		
	private Scanner input;
		
	public Configuration(File f){
		try{
			input = new Scanner(f);
		}catch(Exception exc){
		}
		input.useDelimiter("\n|:| |\t");
		
		input.next();
		String item = input.next();
		loadSubConfig(item);
	}
	
	private void loadSubConfig(String option){
		String item;
		if(option.equals("main")){
			while(input.hasNext()){
				item = input.next();
				if(item.equals("/*")){
					item = input.next();
					input.next();
					loadSubConfig(item);
				}
			}
		}else if(option.startsWith("server")){
			int server = Integer.parseInt(option.substring("server".length()));
			String host = "";
			int tcpPort = 0;
			int udpPort = 0;
			while(input.hasNext()){
				item = input.next();
				if(item.equals("/*")){
					serverOptions.add(new ServerConfig(new InetSocketAddress(host, tcpPort), udpPort));
					
					item = input.next();
					input.next();
					loadSubConfig(item);
					return;
				}
				
				if(item.equals("Host")){
					input.next();
					host = input.next();
				}else if(item.equals("TCP")){
					input.next();
					tcpPort = input.nextInt();
				}else if(item.equals("UDP")){
					input.next();
					udpPort = Integer.parseInt(input.next());
				}

			}
		}else if(option.equals("head")){
			while(input.hasNext()){
				item = input.next();
				if(item.equals("/*")){
					item = input.next();
					input.next();
					loadSubConfig(item);
					return;
				}
				
				if(item.equals("UDP")){
					input.next();
					headUDPPort = Integer.parseInt(input.next());
				}
			}
		}else if(option.equals("tail")){
			while(input.hasNext()){
				item = input.next();
				if(item.equals("/*")){
					item = input.next();
					input.next();
					loadSubConfig(item);
					return;
				}
				
				if(item.equals("UDP")){
					input.next();
					tailUDPPort = Integer.parseInt(input.next());
				}
			}
		}else if(option.startsWith("client")){
			String host = "";
			int udpPort = 0;
			while(input.hasNext()){
				item = input.next();
				if(item.equals("/*")){
					clientListenSocket = new InetSocketAddress(host, udpPort);
					
					item = input.next();
					input.next();
					loadSubConfig(item);
					return;
				}
				
				if(item.equals("Host")){
					input.next();
					host = input.next();
				}else if(item.equals("UDP")){
					input.next();
					udpPort = input.nextInt();
				}else if(item.equals("ReplyTimeout")){
					input.next();
					clientReplyTimeout = input.nextLong();
				}else if(item.equals("UpdateWeight")){
					input.next();
					updateMessagePercentage = input.nextDouble();
				}
			}
		}else if(option.startsWith("master")){
			String host = "";
			int udpPort = 0;
			int tcpPort = 0;
			while(input.hasNext()){
				item = input.next();
				if(item.equals("/*")){
					masterAddress = new InetSocketAddress(host, udpPort);
					masterTCPListenPort = tcpPort;
					item = input.next();
					input.next();
					loadSubConfig(item);
					return;
				}
				
				if(item.equals("UDP")){
					input.next();
					udpPort = Integer.parseInt(input.next());
				}else if(item.equals("Host")){
					input.next();
					host = input.next();
				}else if(item.equals("TCP")){
					input.next();
					tcpPort = input.nextInt();
				}
			}
		}
	}

	public ServerConfig getServerOptions(int id){
		if(id < 0) return null;
		if(id >= serverOptions.size()) return null;
		
		return serverOptions.get(id);
	}
	
	public InetSocketAddress getHeadUDPServer(){
		return new InetSocketAddress(serverOptions.get(0).getHostName(), headUDPPort);
	}
	
	public InetSocketAddress getTailUDPServer(){
		return new InetSocketAddress(serverOptions.get(getTailID()).getHostName(), tailUDPPort);
	}
	
	public long getSeed(){
		return (long)(Math.random() * 10000000l);
	}
	
	public InetSocketAddress getClientListenSocket(){
		return clientListenSocket;
	}
	
	public int getTailID(){
		return serverOptions.size() - 1;
	}
	
	public long getClientReplyTimeout(){
		return clientReplyTimeout;
	}
	
	public double getUpdateMessagePercentage(){
		return updateMessagePercentage;
	}

	public InetSocketAddress getMasterAddress(){
		return masterAddress;
	}

	public int getMasterTCPListenPort(){
		return masterTCPListenPort;
	}
}