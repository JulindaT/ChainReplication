package chainReplication;

import java.net.*;
import java.io.*;
import java.util.*;

public class ChainClient{
	private InetSocketAddress myUDPSocket;
	
	private DatagramSocket tailSocket;
	private InetSocketAddress headAddress, tailAddress;
	private DatagramSocket listenSocket;
	private Random randomGenerator;
	private Message lastMessageSent;
	
	private Vector<ReplyMessage> pendingReplies;
	private Vector<ReplyMessage> receivedReplies;
	
	private long replyTimeout;
	private double updateMessagePercentage;

	private InetSocketAddress masterSocketAddress;
	private Socket masterSocket;

	public ChainClient(InetSocketAddress masterSocketAddress, int udpListenPort, long replyTimeout, double updateMessagePercentage) throws SocketException{
		this(null, null, udpListenPort, replyTimeout, updateMessagePercentage);

		this.masterSocketAddress = masterSocketAddress;
	}
	
	public ChainClient(InetSocketAddress head, InetSocketAddress tail, int udpListenPort, long replyTimeout, double updateMessagePercentage) throws SocketException{
		headAddress = head;
		tailAddress = tail;

		System.out.println("Sending updates to " + head);
		System.out.println("Sending queries to " + tail);

		tailSocket = new DatagramSocket();
		
		listenSocket = new DatagramSocket(udpListenPort);
		pendingReplies = new Vector<ReplyMessage>();
		receivedReplies = new Vector<ReplyMessage>();
		
		randomGenerator = new Random();
		
		this.replyTimeout = replyTimeout;
		this.updateMessagePercentage = updateMessagePercentage;
	}
	
	public void seedRandom(long seed){
		randomGenerator.setSeed(seed);
	}
	
	public void start(){
		startUDPListening();
		startTCPListening();
		while(headAddress == null || tailAddress == null){
			Thread.yield();
		}

		for(int i=0; i<100; i++){
			double random = randomGenerator.nextDouble();
			if(random <= updateMessagePercentage){
				sendUpdate();
			}else{
				sendQuery();
			}

System.out.println("waiting for reply...");
			boolean received = false;
			long sentTime = System.currentTimeMillis();
			while(!received){
				if(System.currentTimeMillis() - sentTime > replyTimeout){
					resendLastMessage();
					sentTime = System.currentTimeMillis();
				}
				for(ReplyMessage r : receivedReplies){
					if(r.id == lastMessageSent.id){
						received = true;
						break;
					}
				}
				Thread.yield();
				receivedReplies.addAll(pendingReplies);
				pendingReplies.clear();
			}
			
			try{
				Thread.sleep((long)(5000l * Math.random()));
			}catch(InterruptedException exc){}
		}
	}
	
	private void startUDPListening(){
		Thread t = new Thread(){
			public void run(){
				while(true){
					byte[] receiveData = new byte[1024];
					try{
						DatagramPacket receivedPacket = new DatagramPacket(receiveData, receiveData.length);
						listenSocket.receive(receivedPacket);
						Message m = Message.deserialize(receivedPacket.getData());
						System.out.println("Received message : " + m.toString());
						if(m instanceof ReplyMessage){
							pendingReplies.add((ReplyMessage)m);
						}
					}catch(IOException exc){
						System.err.println(exc);
					}
				}
			}
		};
		t.start();
	}

	private void startTCPListening(){
		Thread t = new Thread(){
			public void run(){
				try{
					System.out.println("Attempting to connect to master at " + masterSocketAddress);
					masterSocket = new Socket(masterSocketAddress.getAddress(), masterSocketAddress.getPort());
					System.out.println("Connected");
					while(true){
						try{
							Message m = Message.deserialize(masterSocket.getInputStream());
							if(m instanceof UpdateTailServer){
								System.out.println("got new tail address " + ((UpdateTailServer)m).getTailAddress());
								tailAddress = ((UpdateTailServer)m).getTailAddress();
							}else if(m instanceof UpdateHeadServer){
								System.out.println("got new head address " + ((UpdateHeadServer)m).getHeadAddress());
								headAddress = ((UpdateHeadServer)m).getHeadAddress();
							}else{
								System.err.println("Received some junk from the master : " + m);
							}
						}catch(IOException exc){
							System.err.println(exc);
						}
					}
				}catch(Exception exc){
					throw new RuntimeException(exc);
				}
			}
		};
		t.start();
	}
	
	private void sendUpdate(){
		System.out.println("Sending update");
		try{
			UpdateMessage u = new UpdateMessage();
			byte[] data = u.serialize();
			DatagramSocket socket = new DatagramSocket();
			DatagramPacket p = new DatagramPacket(data, data.length, headAddress.getAddress(), headAddress.getPort());
			socket.send(p);
			
			lastMessageSent = u;
		}catch(Exception exc){
			System.err.println("Failed to send update");
			throw new RuntimeException(exc);
		}
	}
	
	private void sendQuery(){
		System.out.println("Sending query");
		try{
			QueryMessage r = new QueryMessage();
			byte[] data = r.serialize();
			
			DatagramSocket socket = new DatagramSocket();
			DatagramPacket p = new DatagramPacket(data, data.length, tailAddress.getAddress(), tailAddress.getPort());
			socket.send(p);
			
			lastMessageSent = r;
		}catch(Exception exc){
			System.err.println("Failed to send query");
			throw new RuntimeException(exc);
		}
	}
	
	private void resendLastMessage(){
		System.out.println("Resending message " + lastMessageSent);
		try{
			if(lastMessageSent instanceof QueryMessage){
				byte[] data = lastMessageSent.serialize();
				
				DatagramSocket socket = new DatagramSocket();
				DatagramPacket p = new DatagramPacket(data, data.length, tailAddress.getAddress(), tailAddress.getPort());
				socket.send(p);
			}else if(lastMessageSent instanceof UpdateMessage){
				byte[] data = lastMessageSent.serialize();
				
				DatagramSocket socket = new DatagramSocket();
				DatagramPacket p = new DatagramPacket(data, data.length, headAddress.getAddress(), headAddress.getPort());
				socket.send(p);
			}
		}catch(Exception exc){
			System.err.println("Failed to resend last message");
		}
	}
}
